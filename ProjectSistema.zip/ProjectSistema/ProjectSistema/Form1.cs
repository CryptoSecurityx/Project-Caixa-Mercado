namespace ProjectSistema
{
	public partial class FrmSistema : Form
	{
		public FrmSistema()
		{
			InitializeComponent();
		}
	}
}